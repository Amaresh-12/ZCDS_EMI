(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("ZCDS_EMI.ZCDS_EMI.ext.upload.manual", {

		onInit: function () {
	var oRootPath = jQuery.sap.getModulePath("ZCDS_EMI.ZCDS_EMI");
		
		var oImageModel = new sap.ui.model.json.JSONModel({
			path : oRootPath,
		});
		
		this.getView().setModel(oImageModel, "imageModel");
		},
		

		upload : function(oevent){
		   var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
  var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
  target: {
  semanticObject: "PORTAL",
  action: "manage"
  }
  
  })) || ""; // generate the Hash to display a Supplier
  oCrossAppNavigator.toExternal({
  target: {
  shellHash: hash
  }
  }); // navigate to Supplier application
  },
		onAfterRendering: function () {
		
		},

		onExit: function () {

		}

	});
})();